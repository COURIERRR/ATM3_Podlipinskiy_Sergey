package kz.iitu.atm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

@Component("atm")
public class ATM {

  @Autowired
  @Qualifier("halykBank")
  private Bank bank;

  public void showMenu() {
    List<String> cardNumbers = Arrays.asList("4406 123 123 123", "4407 123 123 123");
    List<String> balance = Arrays.asList("Your balance");



    Random random = new Random();
    int randIdx = random.nextInt(2);
    String cardNumber = cardNumbers.get(randIdx);

    System.out.println("Your cardNumber and balance: " + cardNumber);


      System.out.println("1. Deposit");
      System.out.println("2. Withdraw");
      System.out.println("3. Check Balance");
      System.out.println("\n4. Exit");

      System.out.println("\n Please enter you choice: ");

    Scanner scanner = new Scanner(System.in);
    Integer choice = scanner.nextInt();
    if (choice == 2) {
      System.out.println("Please enter the sum you want to withdraw: ");
      Double sum = scanner.nextDouble();
      bank.withdraw("4406 123 123 123", sum);
    } else if (choice == 1) {
      System.out.println("What amount do you want to deposit?: " );
      Double sum = scanner.nextDouble();
      bank.deposit("4406 123 123 123", sum);
    } else if (choice == 3) {
      System.out.println("Your balance: ");
      bank.checkBalance("4406 123 123 123");
    }
    showMenu();
  }

}
