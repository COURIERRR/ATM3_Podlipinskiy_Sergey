package kz.iitu.atm;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Configuration
@ComponentScan(basePackages = {"kz.iitu.atm"})
public class SpringConfig {

  @Bean("halykBankAccounts")
  public List<Account> getAccountList() {
    List<Account> accountList = new ArrayList<>();
    accountList.add(new Account(1L, "4406 123 123 123", new Date(), "Bill", 1000.0));
    accountList.add(new Account(2L, "4407 123 123 123", new Date(), "Nick", 2000.0));
    accountList.add(new Account(3L, "4408 123 123 123", new Date(), "Ayan", 3000.0));
    accountList.add(new Account(4L, "4409 123 123 123", new Date(), "Maxim", 4000.0));
    accountList.add(new Account(5L, "4410 123 123 123", new Date(), "Sergey", 5000.0));
    accountList.add(new Account(6L, "4411 123 123 123", new Date(), "Sofia", 26000.0));
    accountList.add(new Account(7L, "4412 123 123 123", new Date(), "Zhanat", 7000.0));
    accountList.add(new Account(8L, "4413 123 123 123", new Date(), "Timur", 8000.0));
    accountList.add(new Account(9L, "4414 123 123 123", new Date(), "Amin", 9000.0));


    return accountList;
  }
}
